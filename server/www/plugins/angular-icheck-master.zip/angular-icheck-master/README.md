# angular-icheck
a icheck directive like jQuery iCheck for angularjs
demo is at index.html
